﻿# Créé par asus pc, le 30/01/2019 en Python 3.4
from tkinter import *
from PIL import Image
#Chargement du programme contenant les résultats des images de référence
from listebase2   import *

def fenetre():
    global myFen,imgGo,imgAff_img,canv
    #on crée la fenêtre et le canvas
    myFen=Tk()
    myFen.geometry('900x800')
    myFen.title('Reconnaissance de caractère')
    myFen.resizable(width=False,height=False)
    canv=Canvas(myFen,height=200,width=100,bg='white')
    canv.place(x=500,y=90)
    imgGo=PhotoImage(file='image/go.gif')
    imgAff_img=PhotoImage(file='image/Afficher_image.gif')
    return

#On place les éléments de la fenêtre
def wid():
    global imgGo,Nom_image,imgAff_img,Nom_seuil,Ldeux
    canv.delete(ALL)
    Ltitre=Label(myFen,font='Arial 15',text='Test de reconnaissance du caractère 2 :')
    Ltitre.place(x=275,y=10)

    Bgo=Button(myFen,image=imgGo,command=go)
    Bgo.place(x=680,y=180)

    Baff=Button(myFen,image=imgAff_img,command=img)
    Baff.place(x=650,y=110)

    Ln_img=Label(myFen,font='Arial 15',text='Nom de l\'image:')
    Ln_img.place(x=47,y=100)
    Nom_image=Entry(myFen)
    Nom_image.place(x=205,y=107)
    Nom_image.insert(0,'2polo_1')

    Lseuil=Label(myFen,font='Arial 15',text='Seuil de correspondance:')
    Lseuil.place(x=32,y=170)
    Nom_seuil=Entry(myFen)
    Nom_seuil.place(x=260,y=177)
    Nom_seuil.insert(0,'25')

    Llabe=Label(myFen,font='Arial 15',text='Fréquences de correspondance aux listes de référence :')
    Llabe.place(x=220,y=480)

    Ldeux=Label(myFen,font='Arial 15',text='')
    Ldeux.place(x=300,y=640)
    return


def transforme():
    """
    Cette fonction decoupe une image de 100x200px en 200 carres de 10 par 10px.
    La variable chaine resultat contiendra les 200 comptages de nombre de pixels noirs
    sous forme de chaine concatenee avec ; comme separateur
    pour la commodite d'utilisation.
    resultat: type string
    couleurs: type list
    noirs: type  int
    """
    # on initialise la chaine resultat en chaine vide
    resultat=""
    # on initialise le nombre de pixels "noirs"
    noir=0
    #on découpe  l' image en 200 carrés (10 colonnes et 20 lignes)
    for colonnes in range(0,10):
        for lignes in range(0,20):
            # on balaie chaque carré pixel par pixel de gauche à droite
            for k in range(colonnes*10,(colonnes+1)*10):
                # et de haut en bas
                for j in range (lignes*10,(lignes+1)*10):
                    coordonnees=(k,j)
                    #on récupère les composantes rgb del'image sous forme d'une liste **couleurs**
                    couleurs=im1.getpixel(coordonnees)
                    r=couleurs[0]
                    v=couleurs[1]
                    b=couleurs[2]
                    if r<20 and b<20 and v<20:
                        noir+=1
            resultat=resultat+str(noir)+";"
            noir=0
    # on supprime le dernier ";"
    resultat=resultat[0:len(resultat)-1]
    return resultat



def creeListe(chaine):
    """
    Cette focntion transforme les chaines ayant ; comme separateur en liste
    chaine: type string
    liste: type list
    """
    liste=chaine.split(';')
    return liste


def distance(L1,L2):
    """
    Cette fonction calcule la distance au carrée entre les deux points formés
    par les listes L1 et L2.
    Chaque liste est considérée ici comme un point dans un espace de dimension 200.
    Les coordonnées des points sont des entiers entre 0 et 100, en les divisant par 100
    on obtient la fréquence de noirs par carre de 10px par 10px.
    Cela revient à diviser la distance (au carre) par 10000.
    La fonction renvoie un arrondi à l'entier le plus proche.
    L1, L2: type list
    d: type int
    """
    d=0
    for i in range(len(L1)):
        d=d+(int(L1[i])-int(L2[i]))**2
    # on divise d par 100*100 ramenant ainsi le calcul de distances entre des listes de frequences
    return round(d/10**4,2)


def match(seuil):
    """
     cette fonction renvoie le nombre de listes qui donnent un distance
     inferieure au seuil fixe
     """
    p=7
    listeRef=creeListe(transforme())
    listeMatch=[]
    nombreOk=0
    for i in base2:
        liste=creeListe(i)
        x=distance(liste,listeRef)
        if x<=float(seuil):
            nombreOk+=1
        p=p+70
        L=Label(myFen,font='Arial 15',text=x,relief='groove')
        L.place(x=p,y=550)
        listeMatch.append(x)
    print(listeMatch)# à écrire dans les 10 labels
    #lancer validation et écrire le résultat dans le label correspondant
    return nombreOk


def validation2(seuil):
    global Ldeux
    if match(seuil)>0:
        Ldeux.config(text="Le chiffre peut être un deux")
    else:
        Ldeux.config(text="Le chiffre n'est pas un deux")

def img():
    global Nom_image,canv,im,im1
    n=Nom_image.get()+'.png'
    im=PhotoImage(file=n)
    canv.create_image(50,100,image=im)
    im1=Image.open(n)
    return

def go():
    global seuil,Nom_seuil,img,im1
    seuil=Nom_seuil.get()
    validation2(seuil)
    return

def reco():
    fenetre()
    wid()

reco()
myFen.mainloop()


